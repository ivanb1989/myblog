package it.cgmconsulting.myblog.entity.common;

public enum ReportigStatus{

	OPEN, IN_PROGRESS,CLOSED_WITH_BAN,CLOSED_WITHOUT_BAN,PERMABAN
}
