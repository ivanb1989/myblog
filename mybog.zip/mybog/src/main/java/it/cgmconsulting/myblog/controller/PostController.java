package it.cgmconsulting.myblog.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.cgmconsulting.myblog.entity.Post;
import it.cgmconsulting.myblog.entity.User;
import it.cgmconsulting.myblog.payload.request.PostRequest;
import it.cgmconsulting.myblog.security.UserPrincipal;
import it.cgmconsulting.myblog.service.PostService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("post")//http:localhost:8080/user/...
@SecurityRequirement(name = "myBlogSecurityScheme")
@Validated
public class PostController{

	private final PostService postService;

	public PostController(PostService postService) {
		this.postService = postService;
	}

	@PostMapping
	@PreAuthorize("hasRole('ROLE_WRITER')")
	public ResponseEntity<?> createPost(@RequestBody @Valid PostRequest postRequest, @AuthenticationPrincipal UserPrincipal userPrincipal) {

		if(postService.existsByTitle((postRequest.getTitle())))
			return new ResponseEntity<>("Post title already present", HttpStatus.BAD_REQUEST);

		Post p = postService.fromRequestToEntity(postRequest, new User(userPrincipal.getId()));
		postService.save(p);
		return new ResponseEntity<>("Post created", HttpStatus.CREATED);
	}

	@GetMapping("/public/boxes")
	public ResponseEntity<?> getBoxes() {
		return new ResponseEntity<>(postService.getPostBoxes(), HttpStatus.OK);
	}

}
