package it.cgmconsulting.myblog.service;

import it.cgmconsulting.myblog.entity.Post;
import it.cgmconsulting.myblog.entity.User;
import it.cgmconsulting.myblog.payload.request.PostRequest;
import it.cgmconsulting.myblog.payload.response.PostBoxesResponse;
import it.cgmconsulting.myblog.repository.PostRepository;
import it.cgmconsulting.myblog.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostService{

	private final PostRepository postRepository;
	private final UserRepository userRepository;

	public PostService(PostRepository postRepository, UserRepository userRepository) {
		this.postRepository = postRepository;
		this.userRepository = userRepository;
	}


	public void save(Post p) {
		postRepository.save(p);
	}

	public Post fromRequestToEntity(PostRequest postRequest, User user) {

		return new Post(postRequest.getTitle(), postRequest.getContent(), postRequest.getOverview(), user);

	}

	public boolean existsByTitle(String title) {
		return postRepository.existsByTitle(title);
	}

public List<PostBoxesResponse> getPostBoxes(){
		return postRepository.getPostBoxes();
}
}
