package it.cgmconsulting.myblog.repository;

import it.cgmconsulting.myblog.entity.Post;
import it.cgmconsulting.myblog.payload.response.PostBoxesResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PostRepository extends JpaRepository<Post, Long>{

	boolean existsByTitle(String title);

	@Query(value = "SELECT new it.cgmconsulting.myblog.payload.response.PostBoxesResponse("+
			"p.id, " +
			"p.title, " +
			"p.overview, " +
			"p.image) " +
			"FROM Post p " +
			"WHERE p.published = true " +
			"ORDER BY p.updateAt DESC")
	List<PostBoxesResponse> getPostBoxes();
}
