package it.cgmconsulting.myblog.repository;

import it.cgmconsulting.myblog.entity.Reason;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReasonRepository extends JpaRepository<Reason,String>{
}
