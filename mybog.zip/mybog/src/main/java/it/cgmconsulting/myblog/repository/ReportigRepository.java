package it.cgmconsulting.myblog.repository;

import it.cgmconsulting.myblog.entity.Comment;
import it.cgmconsulting.myblog.entity.Reporting;
import it.cgmconsulting.myblog.entity.ReportingId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportigRepository extends JpaRepository<Reporting, ReportingId>{
}
