package it.cgmconsulting.myblog.entity;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
public class Reason{

	@Id
	@EqualsAndHashCode.Include
	@Column(length = 30)
	private String id;
}
